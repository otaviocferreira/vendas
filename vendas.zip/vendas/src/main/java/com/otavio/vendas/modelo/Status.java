package com.otavio.vendas.modelo;

public enum Status {

	OK,
	PENDENTE,
	NAO_PROCESSADO
}
