$('.js-moeda').maskNumber({
	decimal : ',',
	thousands : '.'
});